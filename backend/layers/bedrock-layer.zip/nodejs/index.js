/**
 * Wrapper unificado para Amazon Bedrock
 * (agora compatível com modelos Anthropic)
 * â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
 */

import {
  BedrockRuntimeClient,
  InvokeModelCommand
} from "@aws-sdk/client-bedrock-runtime";

const REGION = process.env.AWS_REGION || "us-east-1";
const client = new BedrockRuntimeClient({ region: REGION });

function getProvider(modelId = "") {
  const re = /^(?:[\w-]+\.)*(anthropic|amazon)\./i;   // pega â€œanthropicâ€ ou â€œamazonâ€
  const match = modelId.match(re);
  if (match) return match[1].toLowerCase();

  throw new Error(`Provider não reconhecido em modelId: ${modelId}`);
}

/** CONSTRÓI PAYLOAD CORRETO PARA CADA MODELO */
function buildPayload({ provider, userPrompt, systemPrompt, opts }) {
  const hdrs = { contentType: "application/json", accept: "application/json" };

  if (provider === "amazon") {
    return {
      ...hdrs,
      body: JSON.stringify({
        schemaVersion: "messages-v1",
        system:   [{ text: systemPrompt }],
        messages: [{ role: "user", content: [{ text: userPrompt }] }],
        inferenceConfig: {
          maxTokens:   opts.maxTokens,
          temperature: opts.temperature,
          topP:        opts.topP
        }
      })
    };
  }

  /* ---------- Anthropic (Claude-3) ---------- */
  return {
    ...hdrs,
    body: JSON.stringify({
      system: systemPrompt,                     // â‘  system em nível de topo
      messages: [{ role: "user", content: userPrompt }], // â‘¡ só "user"/"assistant"
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      top_k: opts.topK,
      top_p: opts.topP,
      stop_sequences: ["\nHuman:"],
      anthropic_version: "bedrock-2023-05-31"
    })
  };
}

function extractText(provider, data) {
  if (provider === "amazon" && data?.output) {
    const hdata={
input_tokens:data.usage.inputTokens,
output_tokens:data.usage.outputTokens,
message:data.output.message.content[0].text
    };

    return hdata;
  }

  if (provider === "anthropic" && Array.isArray(data?.content)) {
    const hdata={
input_tokens:data.usage.input_tokens,
output_tokens:data.usage.output_tokens,
message:data.content[0].text
    };

    return hdata;
  }
  return JSON.stringify(data, null, 2);
}

/** FUNÇÃO PRINCIPAL */
export async function callBedrock({
  modelId,
  userPrompt,
  systemPrompt = "Você é um assistente prestativo.",
  maxTokens    = 300,
  temperature  = 0.7,
  topP         = 0.9,
  topK         = 1
} = {}) {
  const provider = getProvider(modelId);
  const payload  = buildPayload({
    provider,
    userPrompt,
    systemPrompt,
    opts: { maxTokens, temperature, topP, topK }
  });

  const command = new InvokeModelCommand({ modelId, ...payload });

  try {
    const { body } = await client.send(command);
    const text = await body.transformToString();
    const data = JSON.parse(text);
    return { statuscode: 200, response: extractText(provider, data) };
  } catch (err) {
    const code = err?.$metadata?.httpStatusCode || 500;
    return { statuscode: code, response: `Erro: ${err.message || err}` };
  }
}
